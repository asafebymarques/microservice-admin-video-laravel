<?php

namespace Illuminate\Database;

use RuntimeException;

class RecordsNotFoundException extends RuntimeException
{
    //
}
